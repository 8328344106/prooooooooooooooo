package com.ct.CertificateTracker.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.ct.CertificateTracker.model.Admin;
import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.model.Tower;
import com.ct.CertificateTracker.model.Vocher;
import com.ct.CertificateTracker.model.VoucherInfo;
import com.ct.CertificateTracker.repository.AdminRepo;
import com.ct.CertificateTracker.repository.CertifiacationDetailsRepo;
import com.ct.CertificateTracker.repository.CertificateRepo;
import com.ct.CertificateTracker.repository.EmployeeRepo;
import com.ct.CertificateTracker.repository.VoucherRepo;

@Service
public class AdminService {
	
	@Autowired
	private EmployeeRepo empRepository;
	
	@Autowired
	private CertificateRepo certificateRepo;
	
	@Autowired
	private CertifiacationDetailsRepo detailsRepo;
	
	@Autowired
	private AdminRepo adminRepo;
	
	@Autowired
	private VoucherRepo voucherRepo;
	
	public List<Tower> getTowers() {
		System.out.println("in admin service\\n\n\n\n");
		List<Employee> temp= empRepository.findAll();
		  Map<String, List<Employee>> groupByTower = 
					temp.stream().collect(Collectors.groupingBy(Employee::getGlobalPractice));
                 // System.out.println("details"+groupByTower.keySet());
		        
		  
		  
		  
		  Set set=groupByTower.entrySet();//Co enverting to Set so that we can traverse  
		    Iterator itr=set.iterator(); 
		    List<Tower> towers=new ArrayList<>();
		    while(itr.hasNext()){  
		    	Tower tower=new Tower();
		        //Converting to Map.Entry so that we can get key and value separately  
		    	Map.Entry entry=(Map.Entry)itr.next();  
		        tower.setTowerName((String)entry.getKey());
		        tower.setEmplist((List<Employee>) entry.getValue());
		        towers.add(tower);
		        
		        
		    }
		    
		    List<Certificate> allCertificates=certificateRepo.findAll();
		    List<CoreCertificationDetails> coreDetails=detailsRepo.findAll();
		    System.out.println(allCertificates);
		    for(Tower t:towers) {
		    	int count=0,ccount=0;
		    	
		    	List<Employee> employees=t.getEmplist();
		    	
		    	for(Employee e:employees)
		    	{	
		    		boolean havingCertification=false, havingCoreCertification=false;
		    	     for(Certificate c:allCertificates) {
		    	    	 if(e.getEmpId().equals((c.getEmpId()))) {
		    	    		 havingCertification=true;
		    	    		 for(CoreCertificationDetails cd:coreDetails)
		    	    		 {
		    	    			 if(c.getCerName().equalsIgnoreCase(cd.getCertificationName()))
		    	    			 {
		    	    				 if(cd.getCoreCeritification().equalsIgnoreCase("yes")) 
		    	    				 {
		    	    					 havingCoreCertification=true;
		    	    					 break;
		    	    				 }
		    	    			 }
		    	    		 }
		    	    		  
		    	    		 
		    	    	 }
		    	    		 
		    	    	 }
		    	     if(havingCertification)
		    	    	 count++;
		    	     if(havingCoreCertification)
		    	    	 ccount++;
		    	     }
		    	t.setTotalEmp(employees.size());
		    	t.setCertifiedEmp(count);
		    	t.setCoreCertified(ccount);
		    	t.setNonCoreCertified(count-ccount);
		    	double y=(((double)t.getCoreCertified()/t.getTotalEmp())*100);
		    	t.setCorePercentage((double)Math.round(y));
		    	double x=(((double)t.getCertifiedEmp()/t.getTotalEmp())*100);
		    	
		    	 t.setPercentage((double) Math.round(x));
		      
		    }
		    
		    
		    
		    
//		    for(Tower t:towers) {
//		    	System.out.println(t.getTowerName()+"  "+t.getTotalEmp()+"   "+t.getCertifiedEmp()+"    "+t.getCoreCertified()+"  "+t.getNonCoreCertified()+"   "+t.getPercentage()+"   "+t.getCorePercentage());
//		    }
		    
		   
		    
		    
		    
		    return towers;
		        
	}
	public List<CoreCertificationDetails> getCertificateDetails(){
		return detailsRepo.findAll();
		
	}
	
	public CoreCertificationDetails addnewCertificate(CoreCertificationDetails c) {
		return detailsRepo.save(c);
		
		
	}
	
	public boolean loginValidate(Admin employe) {
		List<Admin> log=adminRepo.findAll();
		for(Admin e:log) {
			if(e.getEmpId().equals(employe.getEmpId())&&e.getPassword().equals(employe.getPassword()))
				return true;
		}
		return false;
	}
	
	public Admin register(Admin admin) {
		return adminRepo.save(admin);
		
	}
	
	public List<VoucherInfo> getVoucherInfo(){
		List<Vocher> allVouchers = voucherRepo.findAll();
		
		Map<String, List<Vocher>> groupByCertificationName = allVouchers.stream().collect(
				Collectors.groupingBy(Vocher::getExamName));
		// System.out.println("details"+groupByTower.keySet());

		Set set = groupByCertificationName.entrySet();
		Iterator itr = set.iterator();
		List<VoucherInfo> displayedVouchers=new ArrayList<VoucherInfo>();
		
		while (itr.hasNext()) {
			Map.Entry entry = (Map.Entry) itr.next();
			VoucherInfo voucherInfo=new VoucherInfo();
			voucherInfo.setCertificationName((String)entry.getKey());
			List<Vocher> vo=(List<Vocher>)entry.getValue(); 
			int availableCount=0,blockedCount=0,utilizedCount=0,expiredCount=0,totalCount=0;
			String stream=null;
			
			for(Vocher v:vo){
				stream=v.getStream();
				if(v.getStatus().equalsIgnoreCase("Available"))
						availableCount++;
				else if(v.getStatus().equalsIgnoreCase("Blocked"))
					blockedCount++;
				else if(v.getStatus().equalsIgnoreCase("Utilized"))
					utilizedCount++;
				else if(v.getStatus().equalsIgnoreCase("Expired"))
					expiredCount++;
				
				totalCount++;
			}
			
			voucherInfo.setStream(stream);
			voucherInfo.setBlockedCount(blockedCount);
			voucherInfo.setTotalVouchers(totalCount);
			voucherInfo.setUtilizedCount(utilizedCount);
			voucherInfo.setExpiredCount(expiredCount);
			voucherInfo.setAvailableCount(availableCount);
			
			
			displayedVouchers.add(voucherInfo);
			
			
			
			 
				
			}
		
		/*for(VoucherInfo v:displayedVouchers)
		System.out.println(v);
		return null;
		*/	
			
		return displayedVouchers;
		
	}
  
}
