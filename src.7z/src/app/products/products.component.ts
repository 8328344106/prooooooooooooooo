import { Component, OnInit } from '@angular/core';
import {products} from '../products';
import { from } from 'rxjs';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products=new products()
  dataarray=[];
  regForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.regForm = this.fb.group({
      productId: ['', [Validators.required ]],
  
      productName: ['',[ Validators.required] ],
      
      quantity: ['',[Validators.required]],

      price:['',[ Validators.required] ],

      dealer:['',[ Validators.required] ],

      

    });
  }
  onSubmit(){
   console.log(this.products);
  }
}
