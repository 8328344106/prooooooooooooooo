export class CertificatePojo
{ 
    empId: string;
	empName: string;
	cerCategory:string;
	cerName: string;
	cerDate: string;
	expDate: string;
	cerMonth: string;
	examScore: string;
	voucherCode: string;
}