import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatIconRegistry } from '@angular/material';
import { TrackService } from '../track.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-full-emp',
  templateUrl: './full-emp.component.html',
  styleUrls: ['./full-emp.component.css']
})
export class FullEmpComponent implements OnInit {

  // displayedColumns: string[] = ['employeeId', 'employeeName', 'email', 'view'];
  displayedColumns:string[]=['employeeId','employeeName','email','localGrade','grade','mode','cloudJoiningDate',
  'joiningDate','officeLocation','location','seat','benchStartDate','level3EngagementRole',
  'gP','currentAccount','projectCode','projectName','projectStartDate','projectEndDate',
  'primarySkill'];
  dataSource = new MatTableDataSource();
  constructor(private res: TrackService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }
    
  ngOnInit(){
    this.res.getempid().subscribe(res=>
      {
        this.dataSource.data=res;
      });
  }
 
}
