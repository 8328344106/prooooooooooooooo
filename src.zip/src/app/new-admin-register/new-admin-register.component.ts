import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AdminLogPojo } from '../adminlogpojo';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-admin-register',
  templateUrl: './new-admin-register.component.html',
  styleUrls: ['./new-admin-register.component.css']
})
export class NewAdminRegisterComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  register:AdminLogPojo=new AdminLogPojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router) { }

  ngOnInit() {
    this.regForm = this.fb.group({
      name: ['', [Validators.required]],
      
      empId: ['',[Validators.required]],

      password:['',[ Validators.required] ],

      confirmpassword:['',[ Validators.required]],

    });
  }
  reg(){
    this.submitted = true;
    this.register=new AdminLogPojo();

  }
  check=false;
  onRegisterAdmin(){
    this.submitted=true;
    this.check=true;
    this.log.addNewAdmin(this.register)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)
            
            this.route.navigateByUrl('newadminreg');
      });


  }

}
