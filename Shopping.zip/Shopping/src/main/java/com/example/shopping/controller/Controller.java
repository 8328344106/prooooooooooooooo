package com.example.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopping.model.Cart;
import com.example.shopping.model.Inventory;
import com.example.shopping.model.Product;
import com.example.shopping.model.Sales;
import com.example.shopping.service.CartService;
import com.example.shopping.service.InventoryService;
import com.example.shopping.service.ProductService;
import com.example.shopping.service.SalesService;

@RestController
@CrossOrigin("*")
@RequestMapping("/shopping")
public class Controller {
	
	@Autowired
	private InventoryService iService;
	
	@Autowired
	private ProductService prodService;
	
	@Autowired
	private CartService cartService;
	 @Autowired
	 private SalesService salesService;
	 
	
	@GetMapping("/getInventory")
		public List<Inventory> getInventory(){
			return iService.getItem();
			
		}
	
	
	@PostMapping("/addInventory")
	public Inventory addInventory(@RequestBody Inventory inventory) {
		System.out.println(inventory);
		return iService.addItem(inventory);
	}

	@GetMapping("/getProducts")
	public List<Product> getProducts(){
		return prodService.getProduct();
	}
	
	@PostMapping("/addProduct")
	public Product addProducts(@RequestBody Product product) {
		System.out.println(product);
		return prodService.addProduct(product);
		
	}
	
	@GetMapping("/getSales")
	public List<Sales> getAllSales(){
		return salesService.getSales();
	}
	 @PostMapping("/addSales")
	 public Sales addAllSales(Sales sales) {
		 return salesService.addAllSales(sales);
	 }
	 
	 @GetMapping("/getCart")
	 public List<Cart> getCart(){
		 return cartService.getCart();
		 
	 }
	 
	 @PostMapping("/addCart")
	 public Cart addCart(Cart cart) {
		 return cartService.addCart(cart);
	 }
}
