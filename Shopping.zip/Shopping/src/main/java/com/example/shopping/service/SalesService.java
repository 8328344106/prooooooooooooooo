package com.example.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopping.model.Inventory;
import com.example.shopping.model.Sales;
import com.example.shopping.repository.SalesRepository;
import com.example.shopping.repository.inventoryRepository;

@Service
public class SalesService {
	
	@Autowired
	private SalesRepository salesRepo;
	 @Autowired
	 private inventoryRepository inventoryRepo;
	 
	 public List<Sales> getSales(){
		 return salesRepo.findAll();
	 }
	 
	 public List<Inventory> getAllInventory(){
		 return inventoryRepo.findAll();
	 }
	 
	 public Sales addAllSales(Sales sales) {
		 List<Inventory> inventory=inventoryRepo.findAll();
		 for(Inventory i:inventory) {
			 if(sales.getProductId().equals(i.getProductId())) {
				 Integer result;
				 result=(i.getAvailableQty())-(sales.getQuantity());
				 i.setAvailableQty(result);
				  inventoryRepo.save(i);
			 }
		 }
		 return salesRepo.save(sales);
		
	 }
}
