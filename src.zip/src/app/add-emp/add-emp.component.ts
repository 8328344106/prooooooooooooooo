import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmployeePojo } from '../employeePojo';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { TrackService } from '../track.service';

@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {

  regForm: FormGroup;
  model:EmployeePojo = new EmployeePojo();
  submitted: boolean;
  constructor(private http:HttpClient,private fb: FormBuilder, private route:Router,private log:TrackService) { }

  ngOnInit() {
    this.regForm = this.fb.group({

      employeeId:['',[Validators.required]],
      employeeName: ['',[Validators.required]],
      localGrade: ['',[Validators.required]],
      grade: ['',[Validators.required]],
      mode: ['',[Validators.required]],
      cloudJoiningDate: ['',[Validators.required]],
      joiningDate: ['',[Validators.required]],
      officeLocation: ['',[Validators.required]],
      location: ['',[Validators.required]],
      seat: ['',[Validators.required]],
      email: ['',[Validators.required]],
      benchStartDate: ['',[Validators.required]],
      level3EngagementRole: ['',[Validators.required]],
      gP: ['',[Validators.required]],
      currentAccount: ['',[Validators.required]],
      projectCode: ['',[Validators.required]],
      projectName: ['',[Validators.required]],
      projectStartDate: ['',[Validators.required]],
      projectEndDate: ['',[Validators.required]],
      primarySkill: ['',[Validators.required]]

    });
  }
  
  create(){
    this.log.addEmployee(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)
      });


  }

}
