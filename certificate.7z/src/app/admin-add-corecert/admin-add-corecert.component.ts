import { Component, OnInit } from '@angular/core';
import { CoreCertificatePojo } from '../corecertificatepojo';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-admin-add-corecert',
  templateUrl: './admin-add-corecert.component.html',
  styleUrls: ['./admin-add-corecert.component.css']
})
export class AdminAddCorecertComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  model:CoreCertificatePojo=new CoreCertificatePojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AdminAddCorecertComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {
    this.regForm = this.fb.group({
      certificationCategory: ['', [Validators.required ]],
  
      certificationName: ['',[ Validators.required] ],
      
      activeStatus: ['',[Validators.required]],

      coreCeritification:['',[ Validators.required] ],
 
      level:['',[ Validators.required]],

      voucherAvailable: ['',[ Validators.required] ],

    });
  }
  reg(){
    this.submitted = true;
    this.model=new CoreCertificatePojo();

  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;
    this.log.addAdmCer(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)        
            location.href='http://localhost:4200/adminconfig';
      });


  }
   
  onclose(){
    this.dialogref.close();
  }
}
