export class products{

    productId:number;
    productName:string;
    quantity:number;
    price:number;
    dealer:string;
    
}