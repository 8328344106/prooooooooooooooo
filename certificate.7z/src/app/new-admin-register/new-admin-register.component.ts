import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-admin-register',
  templateUrl: './new-admin-register.component.html',
  styleUrls: ['./new-admin-register.component.css']
})
export class NewAdminRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
