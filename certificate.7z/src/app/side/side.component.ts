import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, share } from 'rxjs/operators';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side',
  templateUrl: './side.component.html',
  styleUrls: ['./side.component.css']
})
export class SideComponent {
  
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      share()
    );
   
  constructor(private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router) {
      
    iconRegistry.addSvgIcon(
        'menu',
        sanitizer.bypassSecurityTrustResourceUrl('assets/menu.svg'));
      
      iconRegistry.addSvgIcon(
        'account',
        sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));
      }
      read(){
        return localStorage.getItem('role');
      }
      logout(){
        sessionStorage.setItem('islogins',"false");
        //localStorage.setItem('username',' ');
        localStorage.removeItem('role');
       // this.authservice.logout();
       this.route.navigateByUrl('login');
      }
      readvalue(key){
        //console.log(sessionStorage.getItem('islogins'))
        return sessionStorage.getItem('islogins');
      }
}
