import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlreadyCertificateComponent } from './already-certificate.component';

describe('AlreadyCertificateComponent', () => {
  let component: AlreadyCertificateComponent;
  let fixture: ComponentFixture<AlreadyCertificateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlreadyCertificateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlreadyCertificateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
