package com.ct.CertificateTracker.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.repository.CertificateRepo;
import com.ct.CertificateTracker.repository.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired 
	private EmployeeRepo empRepository;
	
	@Autowired
	private CertificateRepo certificateRepo;
	
	
	public List<Certificate> getCertificates(Integer currentUserId){
		List<Certificate> allCertificates=certificateRepo.findAll();
		List<Certificate> empCertificates=new ArrayList<Certificate>();
		
		
		for(Certificate c:allCertificates) {
			if(c.getEmpId().equals(currentUserId)) {
				empCertificates.add(c);
			}
		}
		
		
		return empCertificates;
		
	}
	
	public Certificate addCertificate(Certificate certificate){
		return certificateRepo.save(certificate);
		
		
	}
	public Certificate updatecertificate(Certificate certificate) {
		List<Certificate> allCertifiactes=certificateRepo.findAll();
		 for(Certificate c:allCertifiactes)
		 {
			 if((c.getEmpId().equals(certificate.getEmpId()))&&(c.getCerName().equals(certificate.getCerName())))
			{
				 certificate.setId(c.getId());
			 }
					 
		
	     }
		 return certificateRepo.save(certificate);
		 

}
	
}