package com.ct.CertificateTracker.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.CoreCertificationDetails;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.service.EmployeeService;

@RestController
@CrossOrigin("*")
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	
	
	/*
	 * private Integer currentUserId=185412; private String currentUser;
	 */
	
	
	@PostMapping("/update")
	public Certificate updateCertificate(@RequestBody Certificate certificate) {
		return service.updatecertificate(certificate);
	}
	
	
	@PostMapping("/add")
	public Certificate addCertificate(@RequestBody Certificate certificate) {
		return service.addCertificate(certificate);
	}
	
	
	
	@GetMapping("/view/{currentUserId}")
	public List<Certificate> getCertificates(@PathVariable String currentUserId){
		return service.getCertificates(currentUserId);
		
	}
	
	@PostMapping("/validate")
	public Employee validate(@RequestBody Employee employe) {
		return service.validate(employe);
	}
	
	
	@GetMapping("/getCertificates")
	public List<CoreCertificationDetails> getCertificateDetails(){
		return service.getCertificateDetails();
		
	}
	
	@GetMapping("/category")
	public Set<String> getCerCatagory(){
		return service.getCerCatigory();
		
	}
	
	
	@GetMapping("/certificates/{category}")
	public List<String> getCertificatesOfCategory(@PathVariable String category){
		return service.getCertificatesOfCategory(category);
		
	}
	@GetMapping("/voucheravailability")
	public boolean voucherAvailable(@RequestParam("stream") String stream,@RequestParam("cerName") String cerName){
		return service.voucherAvailability(stream, cerName);
		
		
		
	}
}
