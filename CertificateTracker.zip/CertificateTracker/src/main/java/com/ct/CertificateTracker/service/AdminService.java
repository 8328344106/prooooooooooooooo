package com.ct.CertificateTracker.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.CertificateTracker.model.Certificate;
import com.ct.CertificateTracker.model.Employee;
import com.ct.CertificateTracker.model.Tower;
import com.ct.CertificateTracker.repository.CertificateRepo;
import com.ct.CertificateTracker.repository.EmployeeRepo;

@Service
public class AdminService {
	
	@Autowired
	private EmployeeRepo empRepository;
	
	@Autowired
	private CertificateRepo certificateRepo;
	
	public List<Employee> getEmp() {
		System.out.println("in admin service\\n\n\n\n");
		List<Employee> temp= empRepository.findAll();
		  Map<String, List<Employee>> groupByTower = 
					temp.stream().collect(Collectors.groupingBy(Employee::getGlobalPractice));
                 // System.out.println("details"+groupByTower.keySet());
		        
		  
		  
		  
		  Set set=groupByTower.entrySet();//Co enverting to Set so that we can traverse  
		    Iterator itr=set.iterator(); 
		    List<Tower> towers=new ArrayList<>();
		    while(itr.hasNext()){  
		    	Tower tower=new Tower();
		        //Converting to Map.Entry so that we can get key and value separately  
		    	Map.Entry entry=(Map.Entry)itr.next();  
		        tower.setTowerName((String)entry.getKey());
		        tower.setEmplist((List<Employee>) entry.getValue());
		        towers.add(tower);
		        
		        
		    }
		    
		    List<Certificate> allCertificates=certificateRepo.findAll();
		    System.out.println(allCertificates);
		    for(Tower t:towers) {
		    	int count=0;
		    	List<Employee> employees=t.getEmplist();
		    	
		    	for(Employee e:employees)
		    	{	
		    	     for(Certificate c:allCertificates) {
		    	    	 if(e.getEmpId().equals((c.getEmpId()))) {
		    	    		 count++;
		    	    		 break;
		    	    		 
		    	    	 }
		    	    		 
		    	    	 }
		    	     }
		    	t.setTotalEmp(employees.size());
		    	t.setCertifiedEmp(count);
		    	double x=(((double)t.getCertifiedEmp()/t.getTotalEmp())*100);
		    	
		    	 t.setPercentage((double) Math.round(x));
		      
		    }
		    
		    
		    
		    
		    for(Tower t:towers) {
		    	System.out.println(t.getTowerName()+"  "+t.getTotalEmp()+"   "+t.getCertifiedEmp()+"    "+t.getPercentage());
		    }
		    
		   
		    
		    
		    
		    return null;
		        
	}
  
}
