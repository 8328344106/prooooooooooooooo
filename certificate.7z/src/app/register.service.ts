import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CertificatePojo } from './certificatepojo';
import { CoreCertificatePojo } from './corecertificatepojo';
import { Tower } from './tower';

@Injectable({
  providedIn: 'root'
})
export class RegisterService 
{
  private baseUrl = 'http://localhost:5555/emp';
  private adminUrl='http://localhost:5555/admin';
  private emp:CertificatePojo;
  constructor(private http:HttpClient) { }
  create(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/register`,register);
  }
  addEmpCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/add`,register);
  }
  validateEmployee(employee: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/validate`,employee);
  }

  addAdmin(admregister:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/register`,admregister);
  }

  validateAdmin(admin:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/login`,admin);
  }

  store(element){
    this.emp=element;
  }

  getalrecerti(){
    
    return this.emp;

  }
  getemployees():Observable<CertificatePojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/all`);
  }
  id=localStorage.getItem('empId');
  eid=+this.id;
  getEmpCer():Observable<CertificatePojo[]>{
    
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/view/`+`${this.eid}`);
  }
  updEmpCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/update`,register);
  }
  getCoreCer():Observable<CoreCertificatePojo[]>{
    return this.http.get<CoreCertificatePojo[]>(`${this.adminUrl}`+`/getCertificates`);
  }
  addAdmCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.adminUrl}`+`/addCertificate`,register);
  }
  getCertificateTotal():Observable<Tower[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<Tower[]>(`${this.adminUrl}`+`/towers`);
  }

  // getVoucherTotal():Observable<CertificatePojo[]>{
  //   //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
  //   return this.http.get<CertificatePojo[]>(`${this.adminUrl}`+`/all`);
  // }
}
