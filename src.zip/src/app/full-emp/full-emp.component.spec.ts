import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullEmpComponent } from './full-emp.component';

describe('FullEmpComponent', () => {
  let component: FullEmpComponent;
  let fixture: ComponentFixture<FullEmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullEmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
