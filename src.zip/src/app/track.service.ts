import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeePojo } from './employeePojo';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TrackService {

  private baseUrl="http://localhost:9090/employee";
  constructor(private http:HttpClient) { }
  addEmployee(model:Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/create`,model);
  }
  getemployees():Observable<EmployeePojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`);
  }
  id=localStorage.getItem('id');
  eid=+this.id;
  getempid():Observable<EmployeePojo[]>{
    
    return this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/getid/`+`${this.eid}`);
  }
  getEmployeesByProjectCode(projectCode: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/findbyProjectcode/${projectCode}`);
  }
 
  getEmployeesByPrimarySkill(primarySkill: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/findbyPrimarySkill/${primarySkill}`);
  }
 


  getEmployeesByLocation(location: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/findbylocation/${location}`);
  }
 
  getEmployeesByGp(gp: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/findbyGp/${gp}`);
  }
 
  deleteEmployee(employeeId: number): Observable<any> {  
    return this.http.delete(`${this.baseUrl}/delete/${employeeId}`, { responseType: 'text' });  
  }
  

}
