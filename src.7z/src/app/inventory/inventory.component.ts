import { Component, OnInit } from '@angular/core';
import {inventory} from '../inventory'
@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
