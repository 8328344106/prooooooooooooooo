package com.example.shopping.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.shopping.model.Inventory;

@Repository
public interface inventoryRepository extends MongoRepository<Inventory, Integer> {

}
