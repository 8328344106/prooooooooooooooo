import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from "@angular/forms";
import {  MatTableDataSource } from '@angular/material/table';
import { ProductserviceService } from '../productservice.service';
import {products} from '../products';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.css']
})
export class SalesComponent implements OnInit {
  
  productForms: FormArray = this.fb.array([]);
  products = [];
  notification = null;
  
  dataarray=[];
  regForm: FormGroup;
  constructor(private fb: FormBuilder,private product:ProductserviceService) { }

  ngOnInit() {
    this.product.getProducts()
    .subscribe(res => this.products = res as []);

  
  }
  

  
}
