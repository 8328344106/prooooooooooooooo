package com.ct.CertificateTracker.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ct.CertificateTracker.model.Tower;
import com.ct.CertificateTracker.service.AdminService;

@RestController
@CrossOrigin("*")
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private AdminService service;
	
	@GetMapping("/towers")
	public Tower getDetails() {
		System.out.println("in admin controller\n\n\n\n");
		service.getEmp();
		return null;
	}

}
