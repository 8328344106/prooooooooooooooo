package com.example.shopping.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopping.model.Inventory;
import com.example.shopping.model.Product;
import com.example.shopping.repository.inventoryRepository;
import com.example.shopping.repository.productRepository;

@Service
public class InventoryService {
	
	@Autowired
	private inventoryRepository inventoryRepo;
	
	@Autowired
	private productRepository productRepo;
	
	public List<Inventory> getItem() {
		return inventoryRepo.findAll();
		
	}
	
	public Inventory addItem(Inventory inventory) {
		Float price;
		Integer qty;
		Float sp;
		Float sellprice;
		List<Product> products=productRepo.findAll();
		
		for(Product p:products) {
			System.out.println("in for loop");
			if(p.getProductId().equals(inventory.getProductId())) {
				
				price=p.getPrice();
				qty=p.getQuantity();
				sp=price/qty;
				sellprice=(float) Math.round((sp*100)/100);
				
				inventory.setSprice(sellprice);
				inventory.setTotalQty(p.getQuantity());
				inventory.setAvailableQty(p.getQuantity());
			}
			
		}
		
		return inventoryRepo.save(inventory);
		
	}

}
