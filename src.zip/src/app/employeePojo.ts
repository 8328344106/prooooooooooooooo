export class EmployeePojo
{
    employeeId: number;
    employeeName: string;
    localGrade: string;
    grade: string;
    mode: string;
    cloudJoiningDate: string;
    joiningDate: string;
    officeLocation: string;
    location: string;
    seat: string;
    email: string;
    benchStartDate: string;
    level3EngagementRole: string;
    gP: string;
    currentAccount: string;
    projectCode: string;
    projectName: string;
    projectStartDate: string;
    projectEndDate: string;
    primarySkill: string
}