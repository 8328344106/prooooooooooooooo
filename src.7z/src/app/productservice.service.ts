import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { products } from './products';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  private baseUrl = 'http://localhost:8080/shopping';

  constructor(private http:HttpClient) { }
  addProducts(formData) {
    return this.http.post(this.baseUrl + '/addProducts', formData);
  }

  getProducts() {
    return this.http.get(this.baseUrl + '/getProducts');
  }

  // deleteBankAccount(id) {
  //   return this.http.delete(this.baseUrl + '/BankAccount/' + id);
  // }

}
