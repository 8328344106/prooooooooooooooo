export class cart{
      productId:number;
	  productName:string;
	  quantity:number;
	  dealer:string;
	  newPrice:number;
}