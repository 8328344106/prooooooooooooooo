export class sales{
    productId:number;
    date:string;
    productName:string;
    quantity:number;
    price:number;
    totalPrice:number;
   
}