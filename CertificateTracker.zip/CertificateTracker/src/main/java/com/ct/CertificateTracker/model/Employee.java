package com.ct.CertificateTracker.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("Employee")
public class Employee {
	
	private String empId;
	private String empName;
	private String localGrade;
	private String mode;
	private String empStatus;
	private String cloudDoj;
	private String joiningDate;
	private String location;
	private String email;
	private String globalPractice;
	private String resignedLwd;
	@Field("Loaned Out")
	private String loanedOut;
	private String billability;
	private String primarySkill;
	private String skillDashboarding;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getLocalGrade() {
		return localGrade;
	}
	public void setLocalGrade(String localGrade) {
		this.localGrade = localGrade;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getEmpStatus() {
		return empStatus;
	}
	public void setEmpStatus(String empStatus) {
		this.empStatus = empStatus;
	}
	public String getCloudDoj() {
		return cloudDoj;
	}
	public void setCloudDoj(String cloudDoj) {
		this.cloudDoj = cloudDoj;
	}
	public String getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGlobalPractice() {
		return globalPractice;
	}
	public void setGlobalPractice(String globalPractice) {
		this.globalPractice = globalPractice;
	}
	public String getResignedLwd() {
		return resignedLwd;
	}
	public void setResignedLwd(String resignedLwd) {
		this.resignedLwd = resignedLwd;
	}
	public String getLoanedOut() {
		return loanedOut;
	}
	public void setLoanedOut(String loanedOut) {
		this.loanedOut = loanedOut;
	}
	public String getBillability() {
		return billability;
	}
	public void setBillability(String billability) {
		this.billability = billability;
	}
	public String getPrimarySkill() {
		return primarySkill;
	}
	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}
	public String getSkillDashboarding() {
		return skillDashboarding;
	}
	public void setSkillDashboarding(String skillDashboarding) {
		this.skillDashboarding = skillDashboarding;
	}
	public Employee(String empId, String empName, String localGrade, String mode, String empStatus, String cloudDoj,
			String joiningDate, String location, String email, String globalPractice, String resignedLwd,
			String loanedOut, String billability, String primarySkill, String skillDashboarding) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.localGrade = localGrade;
		this.mode = mode;
		this.empStatus = empStatus;
		this.cloudDoj = cloudDoj;
		this.joiningDate = joiningDate;
		this.location = location;
		this.email = email;
		this.globalPractice = globalPractice;
		this.resignedLwd = resignedLwd;
		this.loanedOut = loanedOut;
		this.billability = billability;
		this.primarySkill = primarySkill;
		this.skillDashboarding = skillDashboarding;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", localGrade=" + localGrade + ", mode=" + mode
				+ ", empStatus=" + empStatus + ", cloudDoj=" + cloudDoj + ", joiningDate=" + joiningDate + ", location="
				+ location + ", email=" + email + ", globalPractice=" + globalPractice + ", resignedLwd=" + resignedLwd
				+ ", loanedOut=" + loanedOut + ", billability=" + billability + ", primarySkill=" + primarySkill
				+ ", skillDashboarding=" + skillDashboarding + "]";
	}
	
	
	}
