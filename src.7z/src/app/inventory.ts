export class inventory{

    productId:number;
    productName:string;
    totalQty:number;
    availableQty:number;
    sprice:number;
   
}