import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { CertificatePojo } from './certificatepojo';
import { CoreCertificatePojo } from './corecertificatepojo';
import { Tower } from './tower';
import { AdminVoucherPojo } from './adminvoucherpojo';

@Injectable({
  providedIn: 'root'
})
export class RegisterService 
{
  private baseUrl = 'http://localhost:5555/emp';
  private adminUrl='http://localhost:5555/admin';
  private emp:CertificatePojo;
  constructor(private http:HttpClient) { }
  login(){
    console.log("entered service");
    return false;
  }
  create(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/register`,register);
  }
  addEmpCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/add`,register);
  }
  validateEmployee(employee: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/validate`,employee);
  }

  addNewAdmin(admregister:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/register`,admregister);
  }

  validateAdmin(admin:Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/login`,admin);
  }

  store(element){
    this.emp=element;
  }
  getCertificationCategory():Observable<string[]>{
    return this.http.get<string[]>(`${this.baseUrl}`+`/category`);
  }
  // getCertificateName(cerCategory:string):Observable<string[]>{
  //   console.log(cerCategory)
  //   return this.http.get<string[]>(`${this.baseUrl}`+`/certificates/`+`?category=`+`${cerCategory}`);
  // }
  getCertificateName(cerCategory:string):Observable<string[]>{
    console.log(cerCategory)
    return this.http.get<string[]>(`${this.baseUrl}`+`/certificates/`+`${cerCategory}`);
  }
  getalrecerti(){
    
    return this.emp;

  }
  getemployees():Observable<CertificatePojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/all`);
  }
  id=localStorage.getItem('empId');
  eid=+this.id;
  getEmpCer():Observable<CertificatePojo[]>{
    
    return this.http.get<CertificatePojo[]>(`${this.baseUrl}`+`/view/`+`${this.eid}`);
  }
  getEmpNameCer():Observable<CertificatePojo>{
    return this.http.get<CertificatePojo>(`${this.baseUrl}`+`/view/`+`${this.eid}`);
  }
  updEmpCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.baseUrl}`+`/update`,register);
  }
  getCoreCer():Observable<CoreCertificatePojo[]>{
    return this.http.get<CoreCertificatePojo[]>(`${this.adminUrl}`+`/getCertificates`);
  }
  addAdmCer(register: Object): Observable<Object>
  {
    return this.http.post(`${this.adminUrl}`+`/addCertificate`,register);
  }
  getCertificateTotal():Observable<Tower[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<Tower[]>(`${this.adminUrl}`+`/towers`);
  }

  getVoucherTotal():Observable<AdminVoucherPojo[]>{
    //console.log(this.http.get<EmployeePojo[]>(`${this.baseUrl}`+`/all`));
    return this.http.get<AdminVoucherPojo[]>(`${this.adminUrl}`+`/voucherinfo`);
  }
}
