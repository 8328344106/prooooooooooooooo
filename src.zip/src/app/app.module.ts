import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SideComponent } from './side/side.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RouterModule } from '@angular/router';
import {MatTableModule} from '@angular/material/table';
import { AlreadyCertificateComponent } from './already-certificate/already-certificate.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminCertComponent } from './admin-cert/admin-cert.component';
import {MatDialogModule} from '@angular/material/dialog';
import { AddEmpnewcertComponent } from './add-empnewcert/add-empnewcert.component';
import { EditCertComponent } from './edit-cert/edit-cert.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminConfigarationComponent } from './admin-configaration/admin-configaration.component';
import { AdminVocherComponent } from './admin-vocher/admin-vocher.component';
import { AdminAddCorecertComponent } from './admin-add-corecert/admin-add-corecert.component';
import { NewAdminRegisterComponent } from './new-admin-register/new-admin-register.component';
import { EmpRegCerComponent } from './emp-reg-cer/emp-reg-cer.component';
import { MatSelectModule } from '@angular/material/select';

@NgModule({
  declarations: [
    AppComponent,
    SideComponent,
    LoginComponent,
    RegisterComponent,
    AlreadyCertificateComponent,
    AdminLoginComponent,
    AdminCertComponent,
    AddEmpnewcertComponent,
    EditCertComponent,
    AdminDashboardComponent,
    AdminConfigarationComponent,
    AdminVocherComponent,
    AdminAddCorecertComponent,
    NewAdminRegisterComponent,
    EmpRegCerComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatToolbarModule,
    MatDialogModule, 
    MatButtonModule,
    MatSidenavModule,
    MatMenuModule,
    MatInputModule,
    MatTableModule,
    MatIconModule,
    MatListModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path:'login',
        component:LoginComponent
      },
      {
        path:'register',
        component:RegisterComponent
      },
      {
        path:'admincer',
        component:AdminCertComponent
      },
      {
        path:'alreadycert',
        component:AlreadyCertificateComponent
      },
      {
        path:'adminlogin',
        component:AdminLoginComponent
      },
      {
        path:'admindash',
        component:AdminDashboardComponent
      },
      {
        path:'emp-reg-cer',
        component:EmpRegCerComponent
      },
      {
        path:'newadminreg',
        component:NewAdminRegisterComponent
      },
      {
        path:'adminconfig',
        component:AdminConfigarationComponent
      },
      {
        path:'adminvocher',
        component:AdminVocherComponent
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents:[
    LoginComponent,
    AddEmpnewcertComponent,
    EditCertComponent,
    AdminAddCorecertComponent
  ]
})
export class AppModule { }
