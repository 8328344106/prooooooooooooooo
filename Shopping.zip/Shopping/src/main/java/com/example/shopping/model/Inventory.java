package com.example.shopping.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Inventory")
public class Inventory {
	
	@Id
	private Integer productId;
	private String productName;
	private Integer totalQty;
	private Integer availableQty;
	private Float sprice;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	
	public Float getSprice() {
		return sprice;
	}
	public void setSprice(Float sprice) {
		this.sprice = sprice;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getTotalQty() {
		return totalQty;
	}
	public void setTotalQty(Integer totalQty) {
		this.totalQty = totalQty;
	}
	public Integer getAvailableQty() {
		return availableQty;
	}
	public void setAvailableQty(Integer availableQty) {
		this.availableQty = availableQty;
	}
	public Inventory(Integer productId, String productName, Integer totalQty, Integer availableQty, Float sprice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.totalQty = totalQty;
		this.availableQty = availableQty;
		this.sprice = sprice;
	}
	@Override
	public String toString() {
		return "Inventory [productId=" + productId + ", productName=" + productName + ", totalQty=" + totalQty
				+ ", availableQty=" + availableQty + ", sprice=" + sprice + "]";
	}
	
	
}
