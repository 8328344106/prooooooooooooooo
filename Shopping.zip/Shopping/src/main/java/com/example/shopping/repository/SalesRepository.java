package com.example.shopping.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.example.shopping.model.Sales;

@Repository
public interface SalesRepository extends MongoRepository<Sales, Integer>{

}
