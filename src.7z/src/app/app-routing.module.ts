import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductsComponent } from './products/products.component';
import { SalesComponent } from './sales/sales.component';
import { CartComponent } from './cart/cart.component';
import { InventoryComponent } from './inventory/inventory.component';
import { ReportsComponent } from './reports/reports.component';


const routes: Routes = [
  {path:"", redirectTo:"sales",pathMatch:"full"},
  {path:"products",component:ProductsComponent},
  {path:"sales",component:SalesComponent},
  {path:"cart",component:CartComponent},
  {path:"inventory",component:InventoryComponent},
  {path:"reports",component:ReportsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
