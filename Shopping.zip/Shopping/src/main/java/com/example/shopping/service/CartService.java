package com.example.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopping.model.Cart;

import com.example.shopping.repository.CartRepository;



@Service
public class CartService {
	
	
	
	
	@Autowired
	private CartRepository cartRepo;
	
	public List<Cart> getCart(){
		return cartRepo.findAll();
	}
	
	/*setQuantity should be given by user we will have cart button on inventory page so
	 * when we click on cart button all the fields need to be set by default
	 * only quantity need to be user input
	 * with quantity we need to send inventory productId 
	 * Then we can save it here*/
	public Cart addCart(Cart cart) {
		
		
		return cartRepo.save(cart);
	}
        
}
