export class RegisterPojo{
    empId:number;
    password:string;
    confirmpassword:string;
    emailId:string;
    name:string;
}