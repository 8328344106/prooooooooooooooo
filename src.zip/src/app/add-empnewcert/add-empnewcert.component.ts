import { Component, OnInit } from '@angular/core';
import { RegisterPojo } from '../registerpojo';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';
import {MatDialogRef } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';
import { BreakpointObserver } from '@angular/cdk/layout';
import { CertificatePojo } from '../certificatepojo';
import { CoreCertificatePojo } from '../corecertificatepojo';

@Component({
  selector: 'app-add-empnewcert',
  templateUrl: './add-empnewcert.component.html',
  styleUrls: ['./add-empnewcert.component.css']
})
export class AddEmpnewcertComponent implements OnInit {
  regForm: FormGroup;

  submitted= false;

  cerCat:string[];
  cerName:string[];
  model:CertificatePojo=new CertificatePojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<AddEmpnewcertComponent>,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {
      this.log.getCertificationCategory().subscribe(data=>{
        this.cerCat = data as string[];
        console.log(this.cerCat);
      });
      this.regForm = this.fb.group({
        empId: ['', [Validators.required ]],
    
        empName: ['',[ Validators.required] ],
        
        cerCategory: ['',[Validators.required]],

        cerName:['',[ Validators.required] ],
  
        cerDate:['',[ Validators.required]],

        expDate: ['',[ Validators.required] ],
        
        cerMonth: ['',[Validators.required]],

        examScore:['',[ Validators.required] ],
  
        voucherCode:['',[ Validators.required]],
        

      });
  }
  reg(){
    this.submitted = true;
    this.model=new CertificatePojo();

  }
  check=false;
  onAdd(){
    this.submitted=true;
    this.check=true;
    this.log.addEmpCer(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)        
            location.href='http://localhost:4200/alreadycert';
      });


  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerCat);
    });;

  }
  onclose(){
    this.dialogref.close();
  }
}
