import { Component, OnInit } from '@angular/core';
import { CertificatePojo } from '../certificatepojo';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { AddEmpnewcertComponent } from '../add-empnewcert/add-empnewcert.component';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-cert',
  templateUrl: './edit-cert.component.html',
  styleUrls: ['./edit-cert.component.css']
})
export class EditCertComponent implements OnInit {

  regForm: FormGroup;

  submitted= false;
  cerCat:string[];

  cerName:string[];

  model:CertificatePojo=new CertificatePojo();
  mode:CertificatePojo=new CertificatePojo();
  constructor(private fb: FormBuilder,private log:RegisterService,private route:Router,
    private dialogref:MatDialogRef<EditCertComponent>,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }

  ngOnInit() {

    this.mode=this.log.getalrecerti();
    console.log("edit"+this.model.empId);

    this.log.getCertificationCategory().subscribe(data=>{
      this.cerCat = data as string[];
      console.log(this.cerCat);
    });

    this.regForm = this.fb.group({
      empId: [''],
  
      empName: [''],
      
      cerCategory: [''],

      cerName:[''],
 
      cerDate:[''],

      expDate: [''],
      
      cerMonth: [''],

      examScore:[''],
 
      voucherCode:[''],
      

    });
  }
  reg(){
    this.submitted = true;
    this.model=new CertificatePojo();

  }
  check=false;
  onUpdate(){
    this.log.updEmpCer(this.model)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)        
            location.href='http://localhost:4200/alreadycert';
      });


  }
  onCategory(cerCategory)
  {
    console.log(cerCategory);
    this.log.getCertificateName(cerCategory).subscribe(data=>{
      this.cerName = data as string[];
      console.log(this.cerName);
    });;

  }
   
  onclose(){
    this.dialogref.close();
  }
}