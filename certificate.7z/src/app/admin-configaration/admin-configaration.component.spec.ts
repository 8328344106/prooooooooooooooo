import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminConfigarationComponent } from './admin-configaration.component';

describe('AdminConfigarationComponent', () => {
  let component: AdminConfigarationComponent;
  let fixture: ComponentFixture<AdminConfigarationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminConfigarationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminConfigarationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
