package com.ct.CertificateTracker.model;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document("VoucherMaster")
public class Vocher {

	private String voucherCode;
	private String examName;
	@Field("Stream")
	private String stream;
	private String procurementDate;
	private String expiryDate;
	private String status;
	/**
	 * @return the voucherCode
	 */
	public String getVoucherCode() {
		return voucherCode;
	}
	/**
	 * @param voucherCode the voucherCode to set
	 */
	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}
	/**
	 * @return the examName
	 */
	public String getExamName() {
		return examName;
	}
	public Vocher(String voucherCode, String examName, String stream,
			String procurementDate, String expiryDate, String status) {
		super();
		this.voucherCode = voucherCode;
		this.examName = examName;
		this.stream = stream;
		this.procurementDate = procurementDate;
		this.expiryDate = expiryDate;
		this.status = status;
	}
	/**
	 * @param examName the examName to set
	 */
	public void setExamName(String examName) {
		this.examName = examName;
	}
	/**
	 * @return the stream
	 */
	public String getStream() {
		return stream;
	}
	/**
	 * @param stream the stream to set
	 */
	public void setStream(String stream) {
		this.stream = stream;
	}
	/**
	 * @return the procurementDate
	 */
	public String getProcurementDate() {
		return procurementDate;
	}
	/**
	 * @param procurementDate the procurementDate to set
	 */
	public void setProcurementDate(String procurementDate) {
		this.procurementDate = procurementDate;
	}
	/**
	 * @return the expiryDate
	 */
	public String getExpiryDate() {
		return expiryDate;
	}
	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}