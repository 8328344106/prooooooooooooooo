import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-vocher',
  templateUrl: './admin-vocher.component.html',
  styleUrls: ['./admin-vocher.component.css']
})
export class AdminVocherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
