package com.example.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopping.model.Product;
import com.example.shopping.repository.productRepository;

@Service
public class ProductService {
	
	@Autowired
	private productRepository productRepo;
	
	public List<Product> getProduct(){
		return productRepo.findAll();
	}
	
	public Product addProduct(Product product) {
		System.out.println("in for loop");
		System.out.println(product);
		
		return productRepo.save(product);
	}

}
