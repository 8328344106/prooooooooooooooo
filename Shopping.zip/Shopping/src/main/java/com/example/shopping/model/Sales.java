package com.example.shopping.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Sales")
public class Sales {
	
	@Id
	private Integer productId;
	private String date;
	private String productName;
	private Integer quantity;
	private Float price;
	private Float totalPrice;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	
	public Float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Float totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Sales(Integer productId, String date, String productName, Integer quantity, Float price, Float totalPrice) {
		super();
		this.productId = productId;
		this.date = date;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "Sales [productId=" + productId + ", date=" + date + ", productName=" + productName + ", quantity="
				+ quantity + ", price=" + price + ", totalPrice=" + totalPrice + "]";
	}
	
}
