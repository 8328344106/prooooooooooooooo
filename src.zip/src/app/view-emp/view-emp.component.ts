import { Component, OnInit } from '@angular/core';
import { MatTableDataSource, MatIconRegistry } from '@angular/material';
import { TrackService } from '../track.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-emp',
  templateUrl: './view-emp.component.html',
  styleUrls: ['./view-emp.component.css']
})
export class ViewEmpComponent implements OnInit {

  displayedColumns: string[] = ['employeeId', 'employeeName', 'email', 'view'];
  dataSource = new MatTableDataSource();
  searchKey:string;
  constructor(private res: TrackService,private breakpointObserver: BreakpointObserver,
    iconRegistry: MatIconRegistry, 
    sanitizer: DomSanitizer,
    private route:Router) {

    iconRegistry.addSvgIcon(
        'close',
        sanitizer.bypassSecurityTrustResourceUrl('assets/close.svg'));
      }
    
  ngOnInit(){
    this.res.getemployees().subscribe(res=>
      {
        this.dataSource.data=res;
      });
  }
  onview(employeeId){
    localStorage.setItem('id',employeeId);
    //console.log("local get:"+localStorage.getItem('id'));
    this.route.navigateByUrl('empview');
    
  }
  onSearchClear(){
    this.searchKey = "";
    this.applyFilter();

  }
  applyFilter() {
    this.dataSource.filter = this.searchKey.trim().toLowerCase();
  }
}
