package com.example.shopping.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("Cart")
public class Cart {
	
	@Id
	private Integer productId;
	 private String productName;
	 private Integer quantity;
	 private String dealer;
	 private Float newPrice;
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getDealer() {
		return dealer;
	}
	public void setDealer(String dealer) {
		this.dealer = dealer;
	}
	
	public Float getNewPrice() {
		return newPrice;
	}
	public void setNewPrice(Float newPrice) {
		this.newPrice = newPrice;
	}
	public Cart(Integer productId, String productName, Integer quantity, String dealer, Float newPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
		this.dealer = dealer;
		this.newPrice = newPrice;
	}
	@Override
	public String toString() {
		return "Cart [productId=" + productId + ", productName=" + productName + ", quantity=" + quantity + ", dealer="
				+ dealer + ", newPrice=" + newPrice + "]";
	}
	
	 

}
