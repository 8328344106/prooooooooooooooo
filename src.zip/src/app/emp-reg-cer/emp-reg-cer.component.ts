import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-reg-cer',
  templateUrl: './emp-reg-cer.component.html',
  styleUrls: ['./emp-reg-cer.component.css']
})
export class EmpRegCerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
