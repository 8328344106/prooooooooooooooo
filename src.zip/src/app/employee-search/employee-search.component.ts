import { Component, OnInit } from '@angular/core';
import { EmployeePojo } from '../EmployeePojo';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { NgxSmartModalComponent } from 'ngx-smart-modal';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { TrackService } from '../track.service';

@Component({
  selector: 'app-employee-search',
  templateUrl: './employee-search.component.html',
  styleUrls: ['./employee-search.component.css']
})
export class EmployeeSearchComponent implements OnInit {

  projectCode:string;
  primarySkill:string;
  gP:string;
  location:string;
  employees: EmployeePojo[];
  constructor(private dataService: TrackService,public ngxSmartModalService: NgxSmartModalService,
    iconRegistry: MatIconRegistry, 
      sanitizer: DomSanitizer,
       ){
        iconRegistry.addSvgIcon(
          'search',
          sanitizer.bypassSecurityTrustResourceUrl('assets/search.svg'));
      
        }

 
  ngOnInit() {
    this.projectCode = null;
    this.primarySkill=null;
    this.location=null;
    this.gP=null;
  }
 
  private searchEmployeesbyProjectCode() {
    this.dataService.getEmployeesByProjectCode(this.projectCode)
      .subscribe(employees => this.employees = employees);

      this.ngxSmartModalService.getModal('myModal').open();
      
       //document.getElementById("empTable").classList.toggle("show");

  }
 
  private searchEmployeesbyPrimarySkill() {
    this.dataService.getEmployeesByPrimarySkill(this.primarySkill)
      .subscribe(employees => this.employees = employees);
      this.ngxSmartModalService.getModal('myModal').open();

  }
 
  private searchEmployeesbyLocation() {
    this.dataService.getEmployeesByLocation(this.location)
      .subscribe(employees => this.employees = employees);
      this.ngxSmartModalService.getModal('myModal').open();

  }
 
  private searchEmployeesbyGp() {
    this.dataService.getEmployeesByGp(this.gP)
      .subscribe(employees => this.employees = employees);
      this.ngxSmartModalService.getModal('myModal').open();

  }
 


}
